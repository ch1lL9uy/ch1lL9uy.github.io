enc = bytes.fromhex("23a326c27bee9b40885df97007aa4dbe410e93")
key = "Awesome!"
carry = 0

for i, val in enumerate(enc):
    c = val
    c ^= ord(key[i % len(key)])
    c -= carry
    carry += c
    carry %= 256
    print(chr(c&0xff), end='')