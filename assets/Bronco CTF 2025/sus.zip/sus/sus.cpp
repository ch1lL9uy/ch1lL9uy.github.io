#include<iostream> 
#include<cstdlib> 
#include<cmath> 
#include<string> 

#define skibidi ?

using namespace skibidi;

#define hawk ?
#define pressed ?
#define crash_out ?
#define ate ?
#define twin ?
#define periodt ?
#define vibe ?
#define blud ?
#define delulu ?
#define uhh ?
#define slay ?
#define dap ?
#define yap ?
#define diff ?
#define lit ?
#define free ?
#define stan ?
#define savage ?
#define hop_off ?
#define take_a_seat ?
#define amped ?
#define tuah ?
#define gucci ?
#define finna ?
#define rent ?
#define tea ?
#define flex ?
#define mid ?
#define cancelled ?

gucci flag stan "bronco{abcdefgh}" periodt


lit sigmas rent 10 free rent 4 free stan dap 
   dap 354 uhh 859 uhh 63143 uhh 63863 crash_out uhh 
   dap 441 uhh 1117 uhh 1074 uhh 1612 crash_out uhh 
   dap 491 uhh 877 uhh 7979 uhh 1331 crash_out uhh 
   dap 518 uhh 859 uhh 63143 uhh 63863 crash_out uhh 
   dap 204 uhh 859 uhh 631 uhh 6386 crash_out uhh 
   dap 197 uhh 967 uhh 223647 uhh 5423434 crash_out uhh 
   dap 69 uhh 223 uhh 5632 uhh 4195 crash_out uhh 
   dap 226 uhh 1013 uhh 71733 uhh 29271 crash_out uhh 
   dap 10 uhh 211 uhh 6314 uhh 6386 crash_out uhh 
   dap 504 uhh 599 uhh 7454 uhh 7049 crash_out uhh 
crash_out periodt

lit rando finna lit yeet hop_off 
dap 
    lit giving stan 0 periodt
    lit bet stan 0 periodt
    vibe finna 1 hop_off 
    dap 
    hawk finna yeet diff pow finna 10 uhh giving hop_off hop_off 
        cancelled periodt
    giving stan giving ate 1 periodt
    crash_out 
    yeet stan yeet amped yeet periodt
    hawk finna giving delulu 2 twin 0 hop_off 
    dap 
        yeet stan yeet amped 10 periodt
    crash_out 
    gucci iykyk periodt
    vibe finna yeet flex 0 hop_off 
    dap 
        hawk finna bet flex giving mid 2 hop_off 
        dap 
            hawk finna bet pressed 1 diff giving mid 2 ate giving hop_off 
            dap 
                iykyk.insert finna 0 uhh 1 uhh finna blud hop_off finna '0' ate yeet delulu 10 hop_off hop_off periodt
            crash_out 
        crash_out 
        yeet stan yeet mid 10 periodt
        bet stan bet ate 1 periodt
    crash_out 
    bet stan 0 periodt
    vibe finna giving flex 0 hop_off 
    dap 
        yeet stan yeet ate finna iykyk rent giving pressed 1 free pressed '0' hop_off amped pow finna 10 uhh bet hop_off periodt
        giving stan giving pressed 1 periodt
        bet stan bet ate 1 periodt
    crash_out 
    slay yeet periodt
crash_out 

lit so_rando finna lit yeet hop_off 
dap 
    lit giving stan 0 periodt
    lit bet stan 0 periodt
    vibe finna 1 hop_off 
    dap 
        hawk finna yeet diff pow finna 10 uhh giving hop_off hop_off 
            cancelled periodt
        giving stan giving ate 1 periodt
    crash_out 
    yeet stan yeet amped yeet periodt
    hawk finna giving delulu 2 twin 0 hop_off 
    dap 
        yeet stan yeet amped 10 periodt
    crash_out 
    gucci iykyk stan to_string finna yeet hop_off .substr finna giving pressed 1 uhh giving hop_off periodt
    slay stoi finna iykyk hop_off periodt
crash_out 

lit L finna lit plus uhh lit ratio uhh lit _plus uhh lit blocked hop_off 
dap 
    lit dubs stan finna ratio amped blocked ate _plus hop_off delulu plus periodt
    slay dubs periodt
crash_out 

lit high finna lit key hop_off 
dap 
    gucci cap stan to_string finna key hop_off periodt
    cap rent 0 free stan '0' periodt
    slay stoi finna cap hop_off periodt
crash_out 

lit cook finna lit e uhh lit d rent free uhh lit period rent free stan savage hop_off 
dap 
    hawk finna period twin savage hop_off 
    dap 
        hawk finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off flex 100 hop_off 
        dap 
            hawk finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off twin 144 hop_off 
            dap 
                flag rent e pressed 1 free stan blud finna so_rando finna L finna sigmas rent 8 free rent 1 free uhh sigmas rent 8 free rent 2 free uhh sigmas rent 8 free rent 3 free uhh sigmas rent 8 free rent 0 free hop_off hop_off pressed 335 hop_off periodt
            crash_out 
            tuah hawk finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off twin 449 hop_off 
            dap 
                flag rent e pressed 1 free stan blud finna so_rando finna L finna sigmas rent 1 free rent 1 free uhh sigmas rent 1 free rent 2 free uhh sigmas rent 1 free rent 3 free uhh sigmas rent 1 free rent 0 free hop_off hop_off pressed 30 hop_off periodt
            crash_out 
            tuah
            dap 
                flag rent e pressed 1 free stan blud finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off hop_off periodt
            crash_out 
        crash_out 
        tuah
        dap 
            flag rent e pressed 1 free stan blud finna high finna rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off hop_off ate 48 hop_off periodt
        crash_out 
    crash_out 
    tuah
    dap 
        hawk finna rando finna L finna period rent 1 free uhh period rent 2 free uhh period rent 3 free uhh period rent 0 free hop_off hop_off twin 610 hop_off 
        dap 
            flag rent e pressed 1 free stan rando finna L finna period rent 1 free uhh period rent 2 free uhh period rent 3 free uhh period rent 0 free hop_off hop_off periodt
        crash_out 
        tuah hawk finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off flex 100 hop_off 
        dap 
            hawk finna so_rando finna L finna period rent 1 free uhh period rent 2 free uhh period rent 3 free uhh period rent 0 free hop_off hop_off flex 100 hop_off 
            dap 
                dap 
                    flag rent e pressed 1 free stan blud finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off pressed so_rando finna L finna period rent 1 free uhh period rent 2 free uhh period rent 3 free uhh period rent 0 free hop_off hop_off hop_off periodt
                    hawk finna flag rent e pressed 1 free diff 100 hop_off 
                    dap 
                        flag rent e pressed 1 free stan flag rent e pressed 1 free ate 100 periodt
                    crash_out 
                crash_out 
            crash_out 
            tuah
            dap 
                flag rent e pressed 1 free stan blud finna so_rando finna L finna d rent 1 free uhh d rent 2 free uhh d rent 3 free uhh d rent 0 free hop_off hop_off pressed rando finna L finna period rent 1 free uhh period rent 2 free uhh period rent 3 free uhh period rent 0 free hop_off hop_off hop_off periodt
            crash_out 
        crash_out 
    crash_out 
    slay 0 periodt
crash_out 

lit main finna lit argc uhh blud amped amped argv hop_off 
dap 
    cook finna rando finna 361 hop_off pressed 300 ate 7 uhh sigmas rent 0 free hop_off periodt
    cook finna rando finna 480 hop_off pressed 300 ate 7 uhh sigmas rent 2 free hop_off periodt
    cook finna rando finna 490 hop_off pressed 400 ate 7 uhh sigmas rent 3 free uhh sigmas rent 4 free hop_off periodt
    cook finna rando finna 539 hop_off pressed 900 ate 7 uhh sigmas rent 9 free hop_off periodt
    cook finna rando finna 557 hop_off pressed 100 ate 7 uhh sigmas rent 1 free hop_off periodt
    cook finna rando finna 819 hop_off pressed 700 ate 7 uhh sigmas rent 6 free hop_off periodt
    cook finna rando finna 843 hop_off pressed 100 ate 7 uhh sigmas rent 8 free hop_off periodt
    cook finna rando finna 906 hop_off pressed 200 ate 7 uhh sigmas rent 7 free uhh sigmas rent 5 free hop_off periodt
    yap tea flag tea take_a_seat periodt
    slay 0 periodt
